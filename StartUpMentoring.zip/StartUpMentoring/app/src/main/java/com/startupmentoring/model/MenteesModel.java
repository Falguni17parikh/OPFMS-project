package com.startupmentoring.model;

/**
 * Created by admin on 4/16/2020.
 */

public class MenteesModel {
    int resource;
    String fullName;
    String organizationName;
    String idea;
    String postedDate;

    public MenteesModel(int resource, String fullName, String organizationName, String idea, String postedDate) {
        this.resource = resource;
        this.fullName = fullName;
        this.organizationName = organizationName;
        this.idea = idea;
        this.postedDate = postedDate;
    }

    public int getResource() {
        return resource;
    }

    public void setResource(int resource) {
        this.resource = resource;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getOrganizationName() {
        return organizationName;
    }

    public void setOrganizationName(String organizationName) {
        this.organizationName = organizationName;
    }

    public String getIdea() {
        return idea;
    }

    public void setIdea(String idea) {
        this.idea = idea;
    }

    public String getPostedDate() {
        return postedDate;
    }

    public void setPostedDate(String postedDate) {
        this.postedDate = postedDate;
    }
}
