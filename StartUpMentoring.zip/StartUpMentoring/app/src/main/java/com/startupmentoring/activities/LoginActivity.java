package com.startupmentoring.activities;

import android.Manifest;
import android.app.Activity;
import android.app.ActivityOptions;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.startupmentoring.R;
import com.startupmentoring.utilities.Config;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;


public class LoginActivity extends Activity {
    int MyVersion = Build.VERSION.SDK_INT;

    EditText etmbno, etpassword;
    Button btnlogin, btnreg, btnforgot;
    String mbno, password;
    private ProgressDialog mProgress;
    SharedPreferences pref;
    SharedPreferences.Editor editor;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        etmbno = findViewById(R.id.et_mb);
        etpassword = findViewById(R.id.et_password);
        btnlogin = findViewById(R.id.login_btn);
        btnreg = findViewById(R.id.new_user_btn);
        btnforgot = findViewById(R.id.forgot_pwd_btn);
        if (!isNetworkAvailable()) {
            AlertDialog.Builder builder = new AlertDialog.Builder(
                    LoginActivity.this);
            builder.setMessage("Internet Connection Required")
                    .setCancelable(false)
                    .setPositiveButton("Go To Settings",
                            new DialogInterface.OnClickListener() {
                                public void onClick(
                                        DialogInterface dialog,
                                        int id) {
                                    // Restart the activity
                                    Intent intent = new Intent(Settings.ACTION_SETTINGS);
                                    startActivity(intent);

                                }

                            })
                    .setNegativeButton("Cancel",
                            new DialogInterface.OnClickListener() {
                                public void onClick(
                                        DialogInterface dialog,
                                        int id) {
                                    // Restart the activity
                                    dialog.dismiss();
                                    finish();
                                }

                            });

            AlertDialog alert = builder.create();
            alert.show();

        }
        if (MyVersion > Build.VERSION_CODES.LOLLIPOP_MR1) {
            if (!checkIfAlreadyhavePermission()) {
                requestForSpecificPermission();
            }
        }

        btnlogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, MentorDashBoardActivity.class));
            }
        });
        btnreg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this, RegisterActivity.class));
            }
        });
    }

    // Private class isNetworkAvailable
    private boolean isNetworkAvailable() {
        // Using ConnectivityManager to check for Network Connection
        ConnectivityManager connectivityManager = (ConnectivityManager) this
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager
                .getActiveNetworkInfo();
        return activeNetworkInfo != null;
    }

    public void loginData() {
        mProgress.show();
        StringRequest stringRequest = new StringRequest(Request.Method.POST, Config.URL_LOGIN,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {

                        if (response != null) {
                            Log.d("Res", response);
                            mProgress.dismiss();
                            try {
                                JSONObject obj = new JSONObject(response);
                                int isactivated = 0;
                                if (obj.get("status").equals("true")) {
                                    JSONObject jsonObject = new JSONObject(obj.get("record").toString());

                                    String id = jsonObject.getString("id");
                                    String proprietorname = jsonObject.getString("proprietor_name");
                                    String image = jsonObject.getString("image");
                                    String mobileno = jsonObject.getString("mobile_no");
                                    String total_bags = jsonObject.getString("total_bags");
                                    String points = jsonObject.getString("points");

                                    isactivated = Integer.parseInt(jsonObject.getString("isactivated"));
                                    if (isactivated == 1) {
                                        pref = getApplicationContext()
                                                .getSharedPreferences("UserDetails", MODE_PRIVATE);
                                        editor = pref.edit();
                                        editor.putString("memberid", id);
                                        editor.putString("proprietorname", proprietorname);
                                        editor.putString("image", image);
                                        editor.putString("mobileno", mobileno);
                                        editor.putString("totalbags", total_bags);
                                        editor.putString("points", points);
                                        editor.commit();
                                        Toast toast = Toast.makeText(LoginActivity.this, "Login Success!!!", Toast.LENGTH_LONG);
                                        View view = toast.getView();
                                        view.setBackgroundColor(Color.GREEN);
                                        toast.show();
                                        Intent i = new Intent(LoginActivity.this, MentorDashBoardActivity.class);
                                        Bundle bndlanimation =
                                                ActivityOptions.makeCustomAnimation(LoginActivity.this, R.anim.slide_from_left, R.anim.slide_to_right).toBundle();

                                        startActivity(i, bndlanimation);
                                        finish();
                                    } else if (isactivated == 0)
                                        showAlertBox("Admin hasn't Approved you yet", isactivated);

                                } else if (obj.get("status").equals("false"))
                                    showAlertBox(obj.get("message").toString(), isactivated);

                            } catch (JSONException e) {
                                e.printStackTrace();

                            } catch (Exception e) {
                                mProgress.dismiss();
                            }
                        } else {
                            mProgress.dismiss();
                            Toast.makeText(LoginActivity.this, "Invalid Username and Password!!", Toast.LENGTH_LONG).show();
                        }
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(LoginActivity.this, error.toString(), Toast.LENGTH_LONG).show();
                    }
                }) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("username", mbno);
                params.put("password", password);
                return params;
            }

        };

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);

    }

    public void showAlertBox(String msg, int no) {
        AlertDialog.Builder alert = new AlertDialog.Builder(LoginActivity.this);
        alert.setMessage(msg);
        alert.setTitle("Login Failed");
        alert.setCancelable(false);
        alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                dialogInterface.dismiss();
            }
        });
        alert.create().show();
    }

    private boolean checkIfAlreadyhavePermission() {
        int result = ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE);
        if (result == PackageManager.PERMISSION_GRANTED) {
            return true;
        } else {
            Toast.makeText(LoginActivity.this, "Grant permission", Toast.LENGTH_LONG).show();
            return false;
        }
    }

    private void requestForSpecificPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA, Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 101);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        switch (requestCode) {
            case 101:
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    //    Toast.makeText(this, "All Permission Accepted", Toast.LENGTH_SHORT).show();
                } else {
                    //  Toast.makeText(this, "Not Granted", Toast.LENGTH_SHORT).show();
                }
                break;
            default:
                super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }


}
