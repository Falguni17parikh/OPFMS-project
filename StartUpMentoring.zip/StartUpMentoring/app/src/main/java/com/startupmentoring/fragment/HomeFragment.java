package com.startupmentoring.fragment;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.startupmentoring.R;
import com.startupmentoring.adapter.MenteesAdapter;
import com.startupmentoring.model.MenteesModel;

import java.util.ArrayList;
import java.util.List;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {

    private RecyclerView menteesRecyclerView;

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        menteesRecyclerView = view.findViewById(R.id.mentees_recycler_view);
        LinearLayoutManager layoutManager = new LinearLayoutManager((getContext()));
        layoutManager.setOrientation(LinearLayoutManager.VERTICAL);
        menteesRecyclerView.setLayoutManager(layoutManager);
        List<MenteesModel> modelList = new ArrayList<>();
        modelList.add(new MenteesModel(R.drawable.mentor_male, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_female, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_male, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_female, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_male, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_female, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_male, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_female, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_male, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_female, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_male, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_female, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_male, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_female, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_male, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_female, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_male, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_female, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_male, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_female, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_male, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_female, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_male, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_female, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_male, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        modelList.add(new MenteesModel(R.drawable.mentor_female, "Nathan", "Co-Founder,Codepath", "We are working on a project for visually impaired", "On 24th April,2020"));
        MenteesAdapter adapter = new MenteesAdapter(modelList);
        menteesRecyclerView.setAdapter(adapter);
        adapter.notifyDataSetChanged();
        return view;
    }

}
