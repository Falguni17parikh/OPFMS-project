package com.startupmentoring.utilities;

public class Config {

    // API URL configuration
    public static String ADMIN_PANEL_URL = "http://localhost/start-up-mentoring/android/";
    // change this access similar with accesskey in admin panel for security reason
    public static final String URL_REGISTER = ADMIN_PANEL_URL + "register.php";
    public static final String URL_LOGIN = ADMIN_PANEL_URL + "login.php";
    public static final String URL_CHANGE_PASSWORD = ADMIN_PANEL_URL + "change-password.php";

}
