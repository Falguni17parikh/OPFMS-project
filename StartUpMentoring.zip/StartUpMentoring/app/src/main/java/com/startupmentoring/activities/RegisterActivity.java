package com.startupmentoring.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

import com.startupmentoring.R;

public class RegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
    }
}
