package com.startupmentoring.adapter;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.startupmentoring.R;
import com.startupmentoring.model.MenteesModel;

import java.util.List;

/**
 * Created by admin on 4/16/2020.
 */

public class MenteesAdapter extends RecyclerView.Adapter<MenteesAdapter.ViewHolder> {
    private List<MenteesModel> menteesModelList;

    public MenteesAdapter(List<MenteesModel> menteesModelList) {
        this.menteesModelList = menteesModelList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.all_mentees_data_layout, viewGroup, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(ViewHolder viewHolder, int i) {
        int res = menteesModelList.get(i).getResource();
        String name = menteesModelList.get(i).getFullName();
        String org = menteesModelList.get(i).getOrganizationName();
        String postDate = menteesModelList.get(i).getPostedDate();
        String desc = menteesModelList.get(i).getIdea();
        viewHolder.setData(res, name, org, postDate, desc);
    }

    @Override
    public int getItemCount() {
        return menteesModelList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private ImageView profileImage;
        private TextView fullName;
        private TextView organizationName;
        private TextView description;
        private TextView postedDate;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            profileImage = itemView.findViewById(R.id.profileimage);
            fullName = itemView.findViewById(R.id.tv_fullname);
            organizationName = itemView.findViewById(R.id.tv_organisation_name);
            postedDate = itemView.findViewById(R.id.tv_post_date);
            description = itemView.findViewById(R.id.tv_description);

        }

        private void setData(int res, String name, String orgName, String postDate, String desc) {
            profileImage.setImageResource(res);
            fullName.setText(name);
            organizationName.setText(orgName);
            postedDate.setText(postDate);
            description.setText(desc);
        }

    }
}
